const express = require('express');
const db = require('./db');
const utils = require('./utils');
const multer = require('multer');
const upload = multer({dest: 'images/'});



const router = express.Router();



//studentdetails





router.get('/student/:std_id', (request, response) => {
    const std_id = request.params.std_id;
    const connection = db.connect();
    const statement = `select std_id, std_name,  gender, class_name, dob,street_name, city,state,country,postal_code,email_id,uploadeDocument from Order_detail where std_id = ${std_id}`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result[0]));
    })
});

router.get('/student/', (request, response) => {
   //const id_add = request.params.id_add;
    const connection = db.connect();
    const statement = `select std_id, std_name,  gender, class_name, dob,street_name, city,state,country,postal_code,email_id,uploadeDocument  from Student`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});

router.post('/student', (request, response) => {
    const {  std_name,  gender, class_name, dob,street_name, city,state,country,postal_code,email_id,uploadeDocument } = request.body;
    const connection = db.connect();
    const statement = `insert into Student
            ( std_name,  gender, class_name, dob,street_name, city,state,country,postal_code,email_id,uploadeDocument) values 
            ('${std_name}',  '${gender}', '${class_name}', '${dob}', '${street_name}','${city}','${state}','${country}','${postal_code}','${email_id}','${uploadeDocument}')`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});





router.put('/student/:std_id', (request, response) => {
    const std_id = request.params.std_id;
    const {std_name,  gender, class_name, dob,street_name, city,state,country,postal_code,email_id,uploadeDocument} = request.body;
    const connection = db.connect();
    const statement = `update Student
        set
        
        std_name = '${std_name}',
       
        gender = '${gender}',
        class_name = '${class_name}',
        
        dob = '${dob}',
        street_name = '${street_name}',
        city = '${city}',
        state = '${state}',
        country = '${country}',
        postal_code = '${postal_code}',
        email_id = '${email_id}',
        uploadeDocument = '${uploadeDocument}'
        where std_id = ${std_id}`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});

router.delete('/student/:std_id', (request, response) => {
    const std_id = request.params.std_id;
    const connection = db.connect();
    const statement = `delete from Student where std_id = ${std_id}`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});


module.exports=router;